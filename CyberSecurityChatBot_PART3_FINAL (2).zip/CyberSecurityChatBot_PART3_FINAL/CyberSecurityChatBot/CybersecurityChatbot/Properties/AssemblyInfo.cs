using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("CybersecurityChatbot")]
[assembly: AssemblyDescription("Cybersecurity Awareness Chatbot")]
[assembly: AssemblyCompany("IIE")]
[assembly: AssemblyProduct("CybersecurityChatbot")]
[assembly: AssemblyCopyright("Copyright 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("509ba96c-83a0-417a-9296-bbba558c12cb")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
