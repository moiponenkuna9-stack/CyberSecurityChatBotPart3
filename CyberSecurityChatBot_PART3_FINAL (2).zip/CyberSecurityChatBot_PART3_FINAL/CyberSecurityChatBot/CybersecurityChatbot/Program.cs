using System;

namespace CybersecurityAwarenessBot
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Chatbot bot = new Chatbot();
            bot.Run();
        }
    }
}
