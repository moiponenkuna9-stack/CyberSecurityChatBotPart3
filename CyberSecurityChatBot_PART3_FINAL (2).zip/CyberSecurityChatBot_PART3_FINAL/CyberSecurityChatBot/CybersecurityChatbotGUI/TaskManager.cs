using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace CybersecurityChatbotGUI
{
    public class CyberTask
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string Description { get; set; }
        public string ReminderDate { get; set; }
        public bool IsCompleted { get; set; }

        public CyberTask(int id, string title, string description, string reminderDate = "")
        {
            Id = id; Title = title; Description = description;
            ReminderDate = reminderDate; IsCompleted = false;
        }

        public override string ToString()
        {
            string status = IsCompleted ? "✅ Completed" : "⏳ Pending";
            string reminder = string.IsNullOrEmpty(ReminderDate) ? "No reminder set" : "Reminder: " + ReminderDate;
            return $"[{Id}] {Title} — {status}\n    📝 {Description}\n    🔔 {reminder}";
        }
    }

    public class TaskManager
    {
        private List<CyberTask> _tasks = new List<CyberTask>();
        private int _nextId = 1;
        private readonly string _filePath;

        public TaskManager()
        {
            _filePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "tasks.txt");
            LoadTasks();
        }

        public string AddTask(string title, string description, string reminderDate = "")
        {
            var task = new CyberTask(_nextId++, title, description, reminderDate);
            _tasks.Add(task);
            SaveTasks();
            string msg = $"✅ Task added: '{title}'.\n📝 Description: {description}.";
            if (!string.IsNullOrEmpty(reminderDate))
                msg += $"\n🔔 Reminder set for: {reminderDate}.";
            else
                msg += "\n💡 No reminder was set for this task.";
            return msg;
        }

        public string GetAllTasks()
        {
            if (_tasks.Count == 0)
                return "📋 You have no tasks yet. Type 'add task' to create one!";
            var sb = new StringBuilder();
            sb.AppendLine("📋 YOUR CYBERSECURITY TASKS:\n");
            foreach (var t in _tasks)
                sb.AppendLine(t.ToString() + "\n");
            return sb.ToString().TrimEnd();
        }

        public string CompleteTask(int id)
        {
            var task = _tasks.Find(t => t.Id == id);
            if (task == null) return $"❌ No task found with ID {id}.";
            if (task.IsCompleted) return $"✅ Task [{id}] '{task.Title}' is already completed!";
            task.IsCompleted = true;
            SaveTasks();
            return $"✅ Great job! Task [{id}] '{task.Title}' marked as completed! 🎉";
        }

        public string DeleteTask(int id)
        {
            var task = _tasks.Find(t => t.Id == id);
            if (task == null) return $"❌ No task found with ID {id}.";
            _tasks.Remove(task);
            SaveTasks();
            return $"🗑️ Task [{id}] '{task.Title}' has been deleted.";
        }

        public List<CyberTask> GetTaskList() => new List<CyberTask>(_tasks);

        private void SaveTasks()
        {
            try
            {
                var lines = new List<string> { _nextId.ToString() };
                foreach (var t in _tasks)
                    lines.Add($"{t.Id}|{t.Title}|{t.Description}|{t.ReminderDate}|{t.IsCompleted}");
                File.WriteAllLines(_filePath, lines, Encoding.UTF8);
            }
            catch { }
        }

        private void LoadTasks()
        {
            if (!File.Exists(_filePath)) return;
            try
            {
                var lines = File.ReadAllLines(_filePath, Encoding.UTF8);
                if (lines.Length == 0) return;
                int.TryParse(lines[0], out _nextId);
                if (_nextId < 1) _nextId = 1;
                for (int i = 1; i < lines.Length; i++)
                {
                    var parts = lines[i].Split('|');
                    if (parts.Length < 5) continue;
                    var task = new CyberTask(int.Parse(parts[0]), parts[1], parts[2], parts[3]);
                    task.IsCompleted = bool.Parse(parts[4]);
                    _tasks.Add(task);
                }
            }
            catch { }
        }
    }
}
