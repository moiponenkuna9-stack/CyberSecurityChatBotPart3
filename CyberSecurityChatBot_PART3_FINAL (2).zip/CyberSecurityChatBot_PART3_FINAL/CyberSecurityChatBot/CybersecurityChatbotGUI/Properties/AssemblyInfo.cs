using System.Reflection;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("CybersecurityChatbotGUI")]
[assembly: AssemblyDescription("Cybersecurity Awareness Chatbot GUI")]
[assembly: AssemblyCompany("IIE")]
[assembly: AssemblyProduct("CybersecurityChatbotGUI")]
[assembly: AssemblyCopyright("Copyright 2026")]
[assembly: ComVisible(false)]
[assembly: Guid("e11f8e7b-1395-4734-b6ce-1536abab19f3")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
